#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/icmp6.h>
#include <netinet/ip6.h>
#include <arpa/inet.h>
#include <time.h>
#include <ctype.h>
#include <err.h>
#include <netdb.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pcap.h>

#define size 50
#define BUFFER 1024
#define QUEUE (2)
#define LISTENFDS (16)
time_t IDLE_FROM=0;

/**
 * function for sending data
 * */
int serve(int sockfd,char * dev)
{
	char buf[BUFFER];
	char * uk = buf;
	int a,r,n = 5;
	pcap_t *handle;			/* Session handle */
	char errbuf[PCAP_ERRBUF_SIZE];	/* Error string */
	struct bpf_program fp;		/* The compiled filter */
	char filter_exp[] = "ip6 proto \\icmp6";	/* The filter expression */
	bpf_u_int32 mask;		/* Our netmask */
	bpf_u_int32 net;		/* Our IP */
	struct pcap_pkthdr header;	/* The header that pcap gives us */
	const u_char *packet;		/* The actual packet */

	/* Find the properties for the device */
	if (pcap_lookupnet(dev, &net, &mask, errbuf) == -1) {
		fprintf(stderr, "Couldn't get netmask for device %s: %s\n", dev, errbuf);
		net = 0;
		mask = 0;
	}
	/* Open the session in promiscuous mode */
	handle = pcap_open_live(dev, BUFFER, 1, 1000, errbuf);
	if (handle == NULL) {
		fprintf(stderr, "Couldn't open device %s: %s\n", dev, errbuf);
		return 0;
	}
	/* Compile and apply the filter */
	if (pcap_compile(handle, &fp, filter_exp, 0, net) == -1) {
		fprintf(stderr, "Couldn't parse filter %s: %s\n", filter_exp, pcap_geterr(handle));
		return 0;
	}
	if (pcap_setfilter(handle, &fp) == -1) {
		fprintf(stderr, "Couldn't install filter %s: %s\n", filter_exp, pcap_geterr(handle));
		return 0;
	}
	while(1){
		memset(buf,0,BUFFER);
		uk=buf;
		//ziskaj icmp packet a vloz ho do bufferu
	fail:
		packet = NULL;
		/* Grab a packet */
		packet = pcap_next(handle, &header);
		if(!packet){
			goto fail;
		}
		/* Print its timestamp */
		strftime(uk, BUFFER,"%Y%m%d%H%M%S", localtime((const time_t *)&(header.ts.tv_sec)));
		//move forward
		uk +=14;
		char * route = packet;
		//bsd loopback ethernet header
		if(pcap_datalink(handle) == DLT_NULL){
			route += 4;
			//header.len +=6;
		}
		//ethernet header
		else{
			route += 14;
			//header.len +=14;
		}
		//store ip header
		//struct ip6_hdr * ip6;
		//ip6 = (struct ip6_hdr *)(packet);
        //int len = ip6->ip6_plen;
		//skip first 128 bits
		route +=8;
		//buffer
		char pole[BUFFER];
		//clear buffer
		for (a=0;a<200;a++)pole[a]='\0';
		//retrieve source address
		inet_ntop(AF_INET6,route,pole, BUFFER);
		//printf source address
		uk += sprintf(uk,";%s;",pole);
		//move forward
		route +=16;
		//clear buffer
		for (a=0;a<200;a++)pole[a]='\0';
		//retrieve source address
		inet_ntop(AF_INET6,route,pole, BUFFER);
		//print destination address
		uk+= sprintf(uk,"%s;",pole);
		//move forward
		route +=16;
		//print size
		uk+= sprintf(uk,"%d;",header.len);
		//store type
		int code,type,id,seq;
		//change type
		struct icmp6_hdr * ehm = (struct icmp6_hdr *)route;
		type = ehm->icmp6_type;	/* type field */
		code = ehm->icmp6_code;	/* code field */
		if(type == 128 || type == 129){
			id = ehm->icmp6_dataun.icmp6_un_data16[0];	/* type field */
			seq = ehm->icmp6_dataun.icmp6_un_data16[1];
		}
		//print type,id,seq num
		uk+= sprintf(uk,"%d;",type);
		uk+= sprintf(uk,"%d;",code);
		if(type == 128 || type == 129){
			uk+= sprintf(uk,"%d;",id);
			uk+= sprintf(uk,"%d;",seq);
		}
		//print printable data
		route += 4;
		if(type == 128 || type == 129)route += 4;
		for(;header.len > route - (char *)packet;route++)
			if((unsigned char *)*route<32)uk+= sprintf(uk,"-%d-",(unsigned int)*route);
			else uk+= sprintf(uk,"%c",*route);
		uk+= sprintf(uk,";");
		//and send message
		n= strlen(buf);
		r = write(sockfd, buf, n);
		if (r == -1)
			err(1, "write()");
		if (r != n)
			errx(1, "write(): Buffer written just partially");

	}
	//dead code
	return 1;
}

int main(int argc,char * argv[])
{
	//structures for parameters
	int server;
	char address 	[size];
	char interface	[size];
	char file		[size];
	server=2;
	int opt;
	//parsing parametrs
	while((opt = getopt(argc, argv, "r:i:l:o:")) != -1) {
		switch (opt) {
			case 'i':{
			    if(server == 2 || server == 0)server = 0;
			    else{
		        	fprintf(stderr,"HELP:\nusage: -r IP:PORT -i interface_name for capturing icmpv6 messages\nor\n-l port -o output.file");
		        	return 0;
		        }
			    strcpy(interface,optarg);
			}break;
			case 'r':{
				if(server == 2 || server == 0)server = 0;
				else{
				  	fprintf(stderr,"HELP:\nusage: -r IP:PORT -i interface_name for capturing icmpv6 messages\nor\n-l port -o output.file");
				   	return 0;
				}
	            strcpy(address,optarg);
			}break;
	        case 'l':{
	        	if(server == 2 || server == 1)server = 1;
				else{
					fprintf(stderr,"HELP:\nusage: -r IP:PORT -i interface_name for capturing icmpv6 messages\nor\n-l port -o output.file");
	        		return 0;
				}
	            strcpy(address,optarg);
	        }break;
	        case 'o':{
	        	if(server == 2 || server == 1)server = 1;
	        	else{
	        		fprintf(stderr,"HELP:\nusage: -r IP:PORT -i interface_name for capturing icmpv6 messages\nor\n-l port -o output.file");
	        		return 0;
	        	}
	        	strcpy(file,optarg);
	        }break;
	        default:{
		       	fprintf(stderr,"HELP:\nusage: -r IP:PORT -i interface_name for capturing icmpv6 messages\nor\n-l port -o output.file");
		       	return 0;
		    }
		}
	}
	//server mode
	if(server == 1){
		char buf[BUFFER];
		//opening file
		FILE * subor;
		if((subor = fopen(file,"w"))==NULL){
			fprintf(stderr,"error opening file\n");
			return 0;
		}
		int PORT;
		sscanf(address,"%d",&PORT);
		int sock, conn;
		socklen_t clilen;
		struct sockaddr_in6 server_addr, client_addr;
		char addrbuf[INET6_ADDRSTRLEN];


		sock = socket(PF_INET6, SOCK_STREAM, 0);

		if (sock < 0) {
			perror("creating socket");
			exit(0);
		}
		int opt = 0;
		if (setsockopt(sock, IPPROTO_IPV6, IPV6_V6ONLY, &opt, sizeof(opt)) < 0) {
			perror("IPV6_V6ONLY");
			exit(0);
		}
		memset(&server_addr, 0, sizeof(server_addr));

		server_addr.sin6_family = AF_INET6;

		server_addr.sin6_addr = in6addr_any;

		server_addr.sin6_port = htons(PORT);


		if (bind(sock, (struct sockaddr *)&server_addr,
		sizeof(server_addr)) < 0) {
			perror("bind failed");
			exit(0);
		}


		if (listen(sock, BUFFER) < 0) {
			perror("listen failed");
			exit(0);
		}
		int rc;
		while (1) {


			clilen = sizeof(client_addr);
			conn = accept(sock, (struct sockaddr *)&client_addr, &clilen);

			if (conn < 0) {
				perror("accept failed");
				exit(0);
			}
			while(1) {
				if ( (rc = read(conn,buf,BUFFER)) < 0 ) {
					fprintf(stderr,"doRead: reading socket stream");
				    exit(0);
				}
				if(rc != 0){
				  	 IDLE_FROM = time(NULL);
				   	 buf[rc]='\0';
				     fprintf(subor,"%s",buf);
				     fflush(subor);
				     memset(buf,0,BUFFER);
				}
				else{
				 //if server is more than 5 seconds idle
				 if(time(NULL)-IDLE_FROM > 5)break;
				}
			}
			close(conn);
		}
	}
	//pracujeme v rezime klient
	else{
		int ahoj =0;

		int sockfd, n;
		struct addrinfo hints, *res, *ressave;
		bzero(&hints, sizeof(struct addrinfo));
		hints.ai_family=AF_UNSPEC;
		hints.ai_socktype=SOCK_STREAM;
		hints.ai_protocol=IPPROTO_TCP;
		char * adresa = address;
		int naslo = 0;
		while(*adresa != '\0'){
			if(*adresa == ':'){
				naslo = 1;
				break;
			}
			else adresa++;

		}
		if(!naslo){
			fprintf(stderr,"address1 %s",address);
			return 0;
		}

		char * portik = address;
		//koniec argumentu
		while(*portik != '\0')portik++;
		//prvy vyskyt :
		while(*portik != ':')portik--;
		portik++;
		char temp[20];
		int inde =0;
		for(;inde<20;inde++)temp[inde]='\0';
		int hranata = 0;
		adresa = address;
		if(*adresa == '['){
			adresa++;
			portik--;
			hranata = 1;
		}
		strncpy(temp,adresa,portik-adresa-1);
		if(hranata){
			portik++;
		}


		if((n=getaddrinfo(temp, portik, &hints, &res))!=0){
			fprintf(stderr,"address %s\n %s",temp,portik);
			return 0;
		}
		ressave=res;
		do{
			sockfd=socket(res->ai_family, res->ai_socktype, res->ai_protocol);

			if(sockfd<0)
				continue;  /*ignore this returned Ip addr*/

			if(connect(sockfd, res->ai_addr, res->ai_addrlen)==0){
		      break;
		    }
			else{
				//fprintf(stderr,"address");
			}
			close(sockfd);/*ignore this one*/
		}while ((res=res->ai_next)!= NULL);
		if(sockfd < 0){
			fprintf(stderr,"interface not found");
			return 0;
		}
		if(serve(sockfd,interface)==0)return 0;
	}
	return 0;
}
